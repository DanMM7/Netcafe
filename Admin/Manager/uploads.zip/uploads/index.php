<?php
    session_start();

    require './Config/connect.php'; 
?>
        <div>
           <?php
            require './inc/header.php';
           ?>
           
<div class="container">
    <div id="myCarousel" class="slide" data-ride="carousel">
    
      <!-- Wrapper for slides -->
      <div class="carousel-inner">
      
        <div class="item active">
          <img src="./img/netcafe.jpg">
           <div class="carousel-caption">
            <h3></h3>
            <p>  <a href="" target="" class=""></a></p>
          </div>
        </div><!-- End Item -->
 
         <div class="item">
          <img src="./img/netcafe.jpg">
           <div class="carousel-caption">
            <h3</h3>
            
          </div>
        </div><!-- End Item -->
        
        <div class="item">
          <img src="./img/netcafe.jpg">
           <div class="carousel-caption">
           
          </div>
        </div><!-- End Item -->
        
        <div class="item">
          <img src="./img/netcafe.jpg">
           <div class="carousel-caption">
            
          </div>
        </div><!-- End Item -->
                
      </div><!-- End Carousel Inner -->


    	<ul class="nav nav-pills nav-justified">
          <li data-target="#myCarousel" data-slide-to="0" class="active"><a href="#">Burgers<small></small></a></li>
          <li data-target="#myCarousel" data-slide-to="1"><a href="#">Chicken<small></small></a></li>
          <li data-target="#myCarousel" data-slide-to="2"><a href="#">Breakfast<small></small></a></li>
          <li data-target="#myCarousel" data-slide-to="3"><a href="#">Hot Drinks<small></small></a></li>
        </ul>


    </div><!-- End Carousel -->
</div>



<div class="container">
    <div class="row">
        <div class="gallery col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <!--<h1 class="gallery-title">Netcafe Centurion</h1>-->
        </div>
 

<div class="container">
               <h2 style="text-align: center">Our Menu Categories</h2>
               <div class="row">
                   		<?php
							$catsql = "SELECT * FROM category";
							$catres = mysqli_query($connection, $catsql);
							while($catr = mysqli_fetch_assoc($catres)){
						 ?>
							<!-- <li><a href="shop.php?id=<?php echo $catr['id']; ?>"><?php echo $catr['name']; ?></a></li> -->
						
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           <a href="products.php?id=<?php echo $catr['id']; ?>">
                                <img src="img/bf5.jpg" alt="Camera">
                           </a>
                           <center>
                                <div class="caption">
                                        <p id="autoResize"><?php echo $catr['name']; ?></p>
                                        <p>Our wide range of Healthy Breakfasts</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   
                   <!--<div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="products.php">
                               <img src="img/burger1.jpg" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">BURGERS</p>
                                    <p> Our wide range of Burgers</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="products.php">
                               <img src="img/cm1.jpg" alt="Shirt">
                           </a>
                           <center>
                               <div class="caption">
                                   <p id="autoResize">Chicken Meals</p>
                                   <p>Our wide range of Chicken Meals</p>
                               </div>
                           </center>
                       </div>
                   </div>-->
                   <?php } ?>
               </div>
           </div>
            <?php
            require './inc/footer.php';
           ?>          